
for index in 1...180 {
    print("\(index) minus 1 is \(index - 1)")
}

var Timer = 180

if Timer == 180 {
    print ("Timer Stopped")
} else {
    print("Timer is on")
}
